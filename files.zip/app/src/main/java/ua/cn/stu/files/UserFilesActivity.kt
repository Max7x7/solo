package ua.cn.stu.files

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import ua.cn.stu.files.databinding.ActivityFilesBinding

class UserFilesActivity : AppCompatActivity() {

    private val binding by lazy {
        ActivityFilesBinding.inflate(layoutInflater)
    }

    private val openLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            try {
                uri?.let { openFile(it) }
            } catch (e: Exception) {
                showError(R.string.cant_open_file)
            }
        }

    private val saveLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
            try {
                uri?.let { saveFile(it) }
            } catch (e: Exception) {
                showError(R.string.cant_save_file)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        binding.apply {
            openButton.setOnClickListener { openLauncher.launch(arrayOf("text/plain")) }
            saveButton.setOnClickListener { saveLauncher.launch("my-file.txt") }
        }
    }

    private fun openFile(uri: Uri) {
        val data = contentResolver.openInputStream(uri)?.use {
            String(it.readBytes())
        } ?: throw IllegalStateException("Can't open input stream")
        binding.contentEditText.setText(data)
    }

    private fun saveFile(uri: Uri) {
        contentResolver.openOutputStream(uri)?.use {
            val bytes = binding.contentEditText.text.toString().toByteArray()
            it.write(bytes)
        } ?: throw IllegalStateException("Can't open output stream")
    }

    private fun showError(@StringRes res: Int) {
        Toast.makeText(this, res, Toast.LENGTH_SHORT).show()
    }
}