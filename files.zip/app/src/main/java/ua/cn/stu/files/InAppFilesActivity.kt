package ua.cn.stu.files

import android.os.Bundle
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import ua.cn.stu.files.databinding.ActivityFilesBinding
import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStreamReader

class InAppFilesActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityFilesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.apply {
            bindOpenButtonListener()
            bindSaveButtonListener()
        }
    }

    private fun ActivityFilesBinding.bindOpenButtonListener() {
        openButton.setOnClickListener {
            try {
                openFile1()
            } catch (e: Exception) {
                showError(R.string.cant_open_file)
            }
        }
    }

    private fun ActivityFilesBinding.bindSaveButtonListener() {
        saveButton.setOnClickListener {
            try {
                saveFile()
            } catch (e: Exception) {
                showError(R.string.cant_save_file)
            }
        }
    }

    // Open: example with wrappers
    private fun ActivityFilesBinding.openFile1() {
        val file = File(filesDir, FILE_NAME)
        val inputStream = FileInputStream(file)
        val reader = InputStreamReader(inputStream)
        val bufferedReader = BufferedReader(reader)
        val data = bufferedReader.use {
            it.readLines().joinToString(separator = "\n")
        }
        contentEditText.setText(data)
    }

    // Open: example without wrappers
    private fun ActivityFilesBinding.openFile2() {
        val file = File(filesDir, FILE_NAME)
        val data = FileInputStream(file).use {
            String(it.readBytes())
        }
        contentEditText.setText(data)
    }

    private fun ActivityFilesBinding.saveFile() {
        val file = File(filesDir, FILE_NAME)
        FileOutputStream(file).use {
            val bytes = contentEditText.text.toString().toByteArray()
            it.write(bytes)
        }
    }

    private fun showError(@StringRes res: Int) {
        Toast.makeText(this, res, Toast.LENGTH_SHORT).show()
    }

    private companion object {
        const val FILE_NAME = "my-file.txt"
    }

}